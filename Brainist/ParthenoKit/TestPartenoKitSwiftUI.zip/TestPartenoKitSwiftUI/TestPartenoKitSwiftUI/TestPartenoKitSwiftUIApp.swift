//
//  TestPartenoKitSwiftUIApp.swift
//  TestPartenoKitSwiftUI
//
//  Created by Ignazio Finizio on 22/10/2020.
//

import SwiftUI

@main
struct TestPartenoKitSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
